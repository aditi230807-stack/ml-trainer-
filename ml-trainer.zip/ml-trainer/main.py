"""
ML Trainer - FastAPI backend.
Upload any CSV, pick a target + features, train a model, get predictions.
Run locally:  uvicorn main:app --reload
"""
import io
import uuid
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from fastapi import FastAPI, File, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import (GradientBoostingClassifier, GradientBoostingRegressor,
                              RandomForestClassifier, RandomForestRegressor)
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import (accuracy_score, f1_score, mean_absolute_error,
                             mean_squared_error, r2_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

BASE = Path(__file__).parent
DEFAULT_CSV = BASE / "data" / "ice-cream.csv"
MAX_BYTES = 10 * 1024 * 1024        # 10 MB upload limit
MAX_ROWS = 50_000                   # keep free hosting fast

app = FastAPI(title="ML Trainer")
SESSIONS: Dict[str, dict] = {}      # one workspace per browser (X-Session-ID header)


# ----------------------------------------------------------------- helpers
def get_session(sid: Optional[str]) -> dict:
    sid = sid or "default"
    if sid not in SESSIONS:
        SESSIONS[sid] = {"df": pd.read_csv(DEFAULT_CSV), "filename": DEFAULT_CSV.name, "model": None}
    return SESSIONS[sid]


def is_numeric(s: pd.Series) -> bool:
    return pd.api.types.is_numeric_dtype(s) and not pd.api.types.is_bool_dtype(s)


def native(v):
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return None if np.isnan(v) else float(v)
    if v is pd.NA or (isinstance(v, float) and np.isnan(v)):
        return None
    return v


def column_info(df: pd.DataFrame) -> List[dict]:
    """Describe each column so the UI can build inputs for it."""
    info = []
    for c in df.columns:
        s = df[c]
        numeric = is_numeric(s)
        nun = int(s.nunique(dropna=True))
        # text columns with (almost) unique values (dates, ids, names) are not useful features
        usable = numeric or (nun <= 50 and nun / max(len(s), 1) <= 0.5)
        info.append({
            "name": c,
            "kind": "numeric" if numeric else "categorical",
            "unique": nun,
            "usable": bool(usable),
            "options": [] if numeric else sorted(map(str, s.dropna().unique()))[:50],
            "min": native(s.min()) if numeric else None,
            "max": native(s.max()) if numeric else None,
        })
    return info


def dataset_payload(sess: dict) -> dict:
    df = sess["df"]
    prev = df.head(5).astype(object).where(df.head(5).notna(), None)
    return {"filename": sess["filename"], "rows": len(df), "columns": column_info(df),
            "preview": prev.to_dict(orient="records")}


def make_estimator(problem_type: str, model_type: str):
    table = {
        ("regression", "random_forest"): RandomForestRegressor(n_estimators=200, random_state=42, n_jobs=-1),
        ("regression", "gradient_boosting"): GradientBoostingRegressor(random_state=42),
        ("regression", "linear"): LinearRegression(),
        ("classification", "random_forest"): RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1),
        ("classification", "gradient_boosting"): GradientBoostingClassifier(random_state=42),
        ("classification", "linear"): LogisticRegression(max_iter=1000),
    }
    return table[(problem_type, model_type)]


def clean_features(df: pd.DataFrame, features: List[str], numeric_cols: List[str]) -> pd.DataFrame:
    """Numeric -> float, categorical -> object strings with real NaN for missing."""
    X = pd.DataFrame(index=df.index)
    for c in features:
        if c in numeric_cols:
            X[c] = pd.to_numeric(df[c], errors="coerce")
        else:
            X[c] = df[c].astype(object).where(df[c].notna(), np.nan)
            X[c] = X[c].map(lambda v: v if v is np.nan or pd.isna(v) else str(v))
    return X


# ----------------------------------------------------------------- schemas
class TrainRequest(BaseModel):
    problem_type: str = "regression"        # regression | classification
    model_type: str = "random_forest"       # random_forest | gradient_boosting | linear
    target: str
    features: List[str]


class ManualRequest(BaseModel):
    values: Dict[str, Optional[str]]


# ----------------------------------------------------------------- routes
@app.get("/")
def index():
    return FileResponse(BASE / "static" / "index.html")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/api/dataset")
def current_dataset(x_session_id: Optional[str] = Header(None)):
    return dataset_payload(get_session(x_session_id))


@app.post("/api/upload")
async def upload(file: UploadFile = File(...), x_session_id: Optional[str] = Header(None)):
    if not (file.filename or "").lower().endswith(".csv"):
        raise HTTPException(400, "Please choose a .csv file.")
    raw = await file.read()
    if len(raw) > MAX_BYTES:
        raise HTTPException(400, "File is larger than 10 MB.")
    try:
        df = pd.read_csv(io.BytesIO(raw), sep=None, engine="python")   # auto-detects , ; tab
    except Exception:
        raise HTTPException(400, "Could not read this file as CSV.")
    if df.shape[0] < 10 or df.shape[1] < 2:
        raise HTTPException(400, "The CSV needs at least 10 rows and 2 columns.")
    df.columns = [str(c).strip() for c in df.columns]
    if len(df) > MAX_ROWS:
        df = df.sample(MAX_ROWS, random_state=42).reset_index(drop=True)
    sess = get_session(x_session_id)
    sess.update(df=df, filename=file.filename, model=None)
    return dataset_payload(sess)


@app.post("/api/train")
def train(req: TrainRequest, x_session_id: Optional[str] = Header(None)):
    sess = get_session(x_session_id)
    df: pd.DataFrame = sess["df"]
    if req.problem_type not in ("regression", "classification"):
        raise HTTPException(400, "Problem type must be regression or classification.")
    if req.model_type not in ("random_forest", "gradient_boosting", "linear"):
        raise HTTPException(400, "Unknown model type.")
    if req.target not in df.columns:
        raise HTTPException(400, "Choose a target column.")

    info = {c["name"]: c for c in column_info(df)}
    features = [f for f in req.features if f in info and f != req.target and info[f]["usable"]]
    ignored = [f for f in req.features if f not in features and f != req.target]
    if not features:
        raise HTTPException(400, "Select at least one usable feature column.")

    data = df[features + [req.target]].dropna(subset=[req.target])
    if len(data) < 10:
        raise HTTPException(400, "Not enough rows with a target value (need 10+).")
    y = data[req.target]
    if req.problem_type == "regression":
        if not is_numeric(y):
            raise HTTPException(400, f"'{req.target}' is not numeric. Switch to classification.")
    else:
        if y.nunique() > 50:
            raise HTTPException(400, f"'{req.target}' has {y.nunique()} classes. Use regression or another target.")
        y = y.astype(str)

    num_cols = [f for f in features if info[f]["kind"] == "numeric"]
    cat_cols = [f for f in features if f not in num_cols]
    X = clean_features(data, features, num_cols)

    stratify = y if req.problem_type == "classification" and y.value_counts().min() >= 2 else None
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42, stratify=stratify)

    pre = ColumnTransformer([
        ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), num_cols),
        ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                          ("oh", OneHotEncoder(handle_unknown="ignore"))]), cat_cols),
    ])
    pipe = Pipeline([("pre", pre), ("model", make_estimator(req.problem_type, req.model_type))])
    try:
        pipe.fit(X_tr, y_tr)
    except Exception as e:
        raise HTTPException(400, f"Training failed: {e}")
    pred = pipe.predict(X_te)

    if req.problem_type == "regression":
        metrics = {"mae": mean_absolute_error(y_te, pred),
                   "rmse": float(np.sqrt(mean_squared_error(y_te, pred))),
                   "r2": r2_score(y_te, pred)}
    else:
        metrics = {"accuracy": accuracy_score(y_te, pred),
                   "f1": f1_score(y_te, pred, average="weighted")}

    test_rows = data.loc[X_te.index]
    sess.update(model=pipe, features=features, target=req.target, problem_type=req.problem_type,
                num_cols=num_cols, test_rows=test_rows, info=info)

    return {"problem_type": req.problem_type, "model_type": req.model_type,
            "train_rows": len(X_tr), "test_rows": len(X_te),
            "metrics": {k: round(float(v), 4) for k, v in metrics.items()},
            "features": [info[f] for f in features], "ignored": ignored}


def format_prediction(sess: dict, X: pd.DataFrame) -> dict:
    pipe = sess["model"]
    p = pipe.predict(X)[0]
    out = {"prediction": round(float(p), 2) if sess["problem_type"] == "regression" else str(p)}
    if sess["problem_type"] == "classification" and hasattr(pipe, "predict_proba"):
        out["confidence"] = round(float(pipe.predict_proba(X)[0].max()), 4)
    return out


@app.post("/api/predict-sample")
def predict_sample(x_session_id: Optional[str] = Header(None)):
    sess = get_session(x_session_id)
    if sess.get("model") is None:
        raise HTTPException(400, "Train a model first.")
    row = sess["test_rows"].sample(1)
    X = clean_features(row, sess["features"], sess["num_cols"])
    res = format_prediction(sess, X)
    return {"mode": "sample", **res, "actual": native(row[sess["target"]].iloc[0]),
            "inputs": {k: native(v) for k, v in row[sess["features"]].iloc[0].items()}}


@app.post("/api/predict-manual")
def predict_manual(req: ManualRequest, x_session_id: Optional[str] = Header(None)):
    sess = get_session(x_session_id)
    if sess.get("model") is None:
        raise HTTPException(400, "Train a model first.")
    row = {}
    for c in sess["features"]:
        v = req.values.get(c)
        if v is None or str(v).strip() == "":
            row[c] = np.nan                               # imputer fills it in
        elif c in sess["num_cols"]:
            try:
                row[c] = float(v)
            except ValueError:
                raise HTTPException(400, f"{c} must be a number.")
        else:
            row[c] = str(v)
    X = pd.DataFrame([row])
    res = format_prediction(sess, X)
    return {"mode": "manual", **res, "actual": None,
            "inputs": {k: native(v) for k, v in row.items()}}
